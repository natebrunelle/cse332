import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

public class DotProduct {
    static ForkJoinPool POOL = new ForkJoinPool();
    static int CUTOFF;

    // Behavior should match Sequential.dotProduct
    // Your implementation must have linear work and log(n) span
    public static double dotProduct(double[] a, double[]b, int cutoff){
        DotProduct.CUTOFF = cutoff;
        return POOL.invoke(new DotProductTask()); // TODO: add parameters to match your constructor
    }

    private static class DotProductTask extends RecursiveTask<Double>{
        // TODO: select fields

        public DotProductTask(){
            // TODO: implement constructor
        }

        public Double compute(){
            //TODO: Implement.
            return 0.0;
        }
    }
    
}
