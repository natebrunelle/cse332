public class ArrayQueue<T> implements MyQueue<T>{
    // We've provided you several data fields to implement the circular array
    // Feel free to add some more if you need!
    // Please do not change the visibility of [data].
    public T[] data; // store the data
    private int first; // index of the head of the queue
    private int last; // index of the tail of the queue
    private int size; // size of the circular array

    // We've provided you a default implementation of constructor for the ArrayQueue
    public ArrayQueue(){
        this.data = (T[]) new Object[10]; // DO NOT CHANGE INITIAL SIZE HERE
        first = 0;
        last = 0;
    }
}
