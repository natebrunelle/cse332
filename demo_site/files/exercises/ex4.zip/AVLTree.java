public class AVLTree<K extends Comparable<K>, V> extends BinarySearchTree<K, V> {

    public AVLTree() {
        super();
    }

    public V insert(K key, V value) {
        // TODO
        return null;
    }
}
